package com.maandev.terminal

import android.content.Context
import android.util.AttributeSet
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout

class ExtraKeysView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : HorizontalScrollView(context, attrs) {

    private val container: LinearLayout
    var onKeyListener: ((String) -> Unit)? = null
    var onCtrlListener: (() -> Unit)? = null

    // Termux style keys
    private val keys = listOf(
        "ESC", "TAB", "CTRL", "ALT", "/", "-", "|", 
        "HOME", "UP", "END", "PGUP",
        "LEFT", "DOWN", "RIGHT", "PGDN"
    )

    init {
        isHorizontalScrollBarEnabled = false
        container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        addView(container)
        buildKeys()
    }

    private fun buildKeys() {
        keys.forEach { key ->
            val btn = Button(context).apply {
                text = key
                textSize = 12f
                isAllCaps = false
                setPadding(24, 8, 24, 8)
                setOnClickListener {
                    handleKey(key)
                }
            }
            container.addView(btn)
        }
    }

    private fun handleKey(key: String) {
        when (key) {
            "ESC" -> onKeyListener?.invoke("\u001B")
            "TAB" -> onKeyListener?.invoke("\t")
            "CTRL" -> onCtrlListener?.invoke()
            "ALT" -> onKeyListener?.invoke("\u001B") // ALT simulation
            "/" -> onKeyListener?.invoke("/")
            "-" -> onKeyListener?.invoke("-")
            "|" -> onKeyListener?.invoke("|")
            "HOME" -> onKeyListener?.invoke("\u001B[H")
            "UP" -> onKeyListener?.invoke("\u001B[A")
            "END" -> onKeyListener?.invoke("\u001B[F")
            "PGUP" -> onKeyListener?.invoke("\u001B[5~")
            "LEFT" -> onKeyListener?.invoke("\u001B[D")
            "DOWN" -> onKeyListener?.invoke("\u001B[B")
            "RIGHT" -> onKeyListener?.invoke("\u001B[C")
            "PGDN" -> onKeyListener?.invoke("\u001B[6~")
        }
    }

    fun setSpecialKeysEnabled(ctrlActive: Boolean) {
        // Visual feedback for CTRL
        container.getChildAt(2)?.let {
            (it as Button).text = if (ctrlActive) "CTRL*" else "CTRL"
        }
    }
}
