package com.maandev.terminal

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.GZIPInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream

class RootfsInstaller(
    private val ctx: Context,
    private val dest: File,
    private val onLog: (String) -> Unit
) {

    fun install() {
        dest.mkdirs()
        onLog("Starting rootfs install to ${dest.absolutePath}")

        // Option 1: Extract from assets if exists
        val assetList = ctx.assets.list("") ?: emptyArray()
        val rootfsAsset = assetList.firstOrNull { it.startsWith("rootfs") && it.endsWith(".tar.gz") }
        
        if (rootfsAsset != null) {
            onLog("Found asset $rootfsAsset, extracting...")
            extractTarGzFromAssets(rootfsAsset, dest)
        } else {
            // Option 2: Create minimal rootfs structure for testing
            onLog("No rootfs asset found, creating minimal structure...")
            createMinimalRootfs()
        }
        onLog("✓ rootfs install complete")
    }

    private fun extractTarGzFromAssets(assetName: String, dest: File) {
        ctx.assets.open(assetName).use { assetStream ->
            GZIPInputStream(assetStream).use { gzipStream ->
                TarArchiveInputStream(gzipStream).use { tarStream ->
                    var entry = tarStream.nextTarEntry
                    var count = 0
                    while (entry != null) {
                        val outFile = File(dest, entry.name)
                        if (entry.isDirectory) {
                            outFile.mkdirs()
                        } else {
                            outFile.parentFile?.mkdirs()
                            FileOutputStream(outFile).use { tarStream.copyTo(it) }
                        }
                        count++
                        if (count % 500 == 0) onLog("Extracted $count files...")
                        entry = tarStream.nextTarEntry
                    }
                    onLog("Extracted total $count files")
                }
            }
        }
    }

    private fun createMinimalRootfs() {
        // Create basic linux directory structure so proot can start
        listOf("bin", "etc", "root", "tmp", "dev", "proc", "sys", "usr/bin", "var/tmp").forEach {
            File(dest, it).mkdirs()
        }
        File(dest, "etc/passwd").writeText("root:x:0:0:root:/root:/bin/bash\n")
        File(dest, "etc/hosts").writeText("127.0.0.1 localhost\n")
        // NOTE: Real bash will be copied from device if minimal
        // For production, replace this with downloading ubuntu/debian rootfs from proot-distro
        onLog("Minimal rootfs created. Add real rootfs.tar.gz to assets for full Linux.")
    }
}
