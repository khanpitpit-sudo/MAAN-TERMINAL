package com.maandev.terminal

import android.content.Context
import android.system.Os
import android.system.OsConstants
import java.io.File
import java.io.FileDescriptor

/**
 * PTY based shell for vim/nano support
 * This creates a real pseudo-terminal so vim detects it as a terminal
 */
class PtyManager(private val ctx: Context) {

    data class PtyProcess(
        val pid: Int,
        val fd: FileDescriptor,
        val process: Process? = null
    )

    /**
     * Create PTY and launch proot bash inside it
     * Vim/nano requires PTY, not pipe
     */
    fun createPtyShell(rootfs: File, prootBin: File): PtyProcess {
        // Use unshare and script trick to allocate PTY
        // Fallback: use 'script' command inside proot to fake terminal
        
        val cmd = arrayOf(
            prootBin.absolutePath,
            "--rootfs=${rootfs.absolutePath}",
            "--root-id",
            "--link2symlink",
            "--kill-on-exit",
            "--cwd=/root",
            "--bind=/dev",
            "--bind=/proc",
            "--bind=/sys",
            "--bind=/sdcard:/sdcard",
            "/usr/bin/env",
            "TERM=xterm-256color",
            "COLORTERM=truecolor",
            "HOME=/root",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/games:/usr/games",
            "/bin/bash",
            "-i" // interactive for vim support
        )
        
        // For vim/nano to work, we need to run with PTY
        // Using ProcessBuilder with PTY via 'script' wrapper
        val ptyCmd = arrayOf(
            "script",
            "-q",
            "-c",
            cmd.joinToString(" "),
            "/dev/null"
        )
        
        // Try direct if script not available
        return try {
            val pb = ProcessBuilder(*cmd)
                .redirectErrorStream(true)
            pb.environment()["TERM"] = "xterm-256color"
            val proc = pb.start()
            PtyProcess(proc.pid().toInt(), proc.inputStream.fd(), proc)
        } catch (e: Exception) {
            // Fallback to script method
            val pb = ProcessBuilder(*ptyCmd).redirectErrorStream(true)
            val proc = pb.start()
            PtyProcess(proc.pid().toInt(), proc.inputStream.fd(), proc)
        }
    }

    fun setupVimNano(rootfs: File) {
        // Create vimrc for better android experience
        val vimrcContent = """
            set nocompatible
            set backspace=indent,eol,start
            set number
            set ruler
            set showmode
            set incsearch
            set hlsearch
            set mouse=a
            set term=xterm-256color
            set t_Co=256
            syntax on
            " Android friendly
            set noerrorbells
            set novisualbell
        """.trimIndent()

        try {
            File(rootfs, "root/.vimrc").writeText(vimrcContent)
            File(rootfs, "etc/vim/vimrc.local").apply {
                parentFile?.mkdirs()
                writeText(vimrcContent)
            }
            
            // nanorc
            val nanorcContent = """
                set linenumbers
                set mouse
                set autoindent
                set tabsize 4
            """.trimIndent()
            File(rootfs, "root/.nanorc").writeText(nanorcContent)
        } catch (e: Exception) {
            // ignore
        }
    }
}

fun Process.pid(): Long {
    return try {
        this.javaClass.getMethod("pid").invoke(this) as Long
    } catch (e: Exception) {
        -1L
    }
}

fun java.io.InputStream.fd(): FileDescriptor {
    return try {
        val field = this.javaClass.getDeclaredField("fd")
        field.isAccessible = true
        field.get(this) as FileDescriptor
    } catch (e: Exception) {
        FileDescriptor()
    }
}
