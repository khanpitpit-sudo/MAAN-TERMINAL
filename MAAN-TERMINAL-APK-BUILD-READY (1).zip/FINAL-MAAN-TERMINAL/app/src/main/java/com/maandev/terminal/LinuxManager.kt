package com.maandev.terminal

import android.content.Context
import java.io.File

class LinuxManager(private val ctx: Context) {
    
    val baseDir: File = File(ctx.filesDir, "../../maan-terminal").canonicalFile
    val prootBin: File = File(baseDir, "proot")
    val rootfsDir: File = File(baseDir, "rootfs")
    val homeDir: File = File(rootfsDir, "root")

    fun init(onLog: (String) -> Unit, onReady: () -> Unit, onError: (String) -> Unit) {
        Thread {
            try {
                baseDir.mkdirs()
                onLog("Base dir: ${baseDir.absolutePath}")

                // 1. Setup proot binary from assets
                if (!prootBin.exists()) {
                    onLog("Extracting proot binary...")
                    extractAsset("proot", prootBin)
                }
                prootBin.setExecutable(true)
                onLog("✓ proot ready")

                // 2. Setup rootfs
                if (!isRootfsValid()) {
                    onLog("Installing rootfs, please wait...")
                    val installer = RootfsInstaller(ctx, rootfsDir, onLog)
                    installer.install()
                } else {
                    onLog("✓ rootfs found")
                }

                // 3. Create essential binds
                File(rootfsDir, "sdcard").mkdirs()
                
                onReady()
            } catch (e: Exception) {
                onError(e.stackTraceToString())
            }
        }.start()
    }

    private fun isRootfsValid(): Boolean {
        return File(rootfsDir, "bin/bash").exists() || File(rootfsDir, "usr/bin/bash").exists()
    }

    private fun extractAsset(assetName: String, dest: File) {
        ctx.assets.open(assetName).use { input ->
            dest.outputStream().use { output ->
                input.copyTo(output)
            }
        }
    }

    fun getLaunchCommand(): Array<String> {
        return ProotManager(ctx).buildCommand(rootfsDir, prootBin)
    }
}
