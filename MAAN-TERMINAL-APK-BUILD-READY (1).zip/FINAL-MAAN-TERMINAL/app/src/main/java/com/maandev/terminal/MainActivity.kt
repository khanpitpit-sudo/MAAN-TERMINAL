
package com.maandev.terminal

import android.os.Bundle
import android.view.KeyEvent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var terminalView: TextView
    private lateinit var inputView: EditText
    private lateinit var scrollView: ScrollView
    private lateinit var linuxManager: LinuxManager
    private lateinit var terminalBridge: TerminalBridge

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        scrollView = ScrollView(this)
        terminalView = TextView(this).apply {
            text = "MAAN-TERMINAL v1.0 - Proot Ubuntu\n"
            setTextIsSelectable(true)
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(16,16,16,16)
        }
        scrollView.addView(terminalView)

        inputView = EditText(this).apply {
            hint = "$ type command..."
            typeface = android.graphics.Typeface.MONOSPACE
            setSingleLine(true)
        }

        val layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0, 1f
        )
        rootLayout.addView(scrollView, layoutParams)
        rootLayout.addView(inputView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        setContentView(rootLayout)

        linuxManager = LinuxManager(this)
        terminalBridge = TerminalBridge(this, terminalView, scrollView)

        inputView.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                val cmd = inputView.text.toString()
                if (cmd.isNotBlank()) {
                    terminalBridge.sendCommand(cmd)
                    inputView.text.clear()
                }
                true
            } else false
        }

        appendLog("Checking runtime...")
        linuxManager.init(
            onLog = { appendLog(it) },
            onReady = { appendLog("✓ Linux ready, starting shell...\n"); startTerminal() },
            onError = { appendLog("✗ Error: $it") }
        )
    }

    private fun startTerminal() {
        val cmd = linuxManager.getLaunchCommand()
        terminalBridge.openShell(cmd)
    }

    private fun appendLog(msg: String) {
        runOnUiThread {
            terminalView.append(msg + "\n")
            scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }
}
