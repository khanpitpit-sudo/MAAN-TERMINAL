package com.maandev.terminal

import android.content.Context
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class TerminalBridge(
    private val ctx: Context,
    private val terminalView: TextView,
    private val scrollView: ScrollView
) {

    private var process: Process? = null
    private var writer: OutputStreamWriter? = null
    private var readerThread: Thread? = null

    fun openShell(cmd: Array<String>) {
        Thread {
            try {
                log("Launching: ${cmd.joinToString(" ")}")
                val pb = ProcessBuilder(*cmd)
                    .redirectErrorStream(true)
                
                // Set env
                pb.environment()["TERM"] = "xterm-256color"
                pb.environment()["HOME"] = "/root"
                pb.environment()["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
                pb.environment()["PROOT_TMP_DIR"] = ctx.cacheDir.absolutePath

                process = pb.start()
                writer = OutputStreamWriter(process!!.outputStream)

                // Read output loop
                readerThread = Thread {
                    val reader = BufferedReader(InputStreamReader(process!!.inputStream))
                    val buffer = CharArray(1024)
                    try {
                        while (true) {
                            val len = reader.read(buffer)
                            if (len == -1) break
                            val text = String(buffer, 0, len)
                            logRaw(text)
                        }
                    } catch (e: Exception) {
                        log("\n[Shell exited: ${e.message}]")
                    }
                }.apply { start() }

                // Wait
                process!!.waitFor()
                log("\n[Process exited with ${process!!.exitValue()}]")

            } catch (e: Exception) {
                log("\n[Failed to start shell: ${e.stackTraceToString()}]")
            }
        }.start()
    }

    fun sendCommand(cmd: String) {
        try {
            writer?.apply {
                write(cmd + "\n")
                flush()
            }
            log("\n$ $cmd\n")
        } catch (e: Exception) {
            log("\n[Write error: ${e.message}]")
        }
    }

    fun exec(cmd: String): String {
        return try {
            val p = Runtime.getRuntime().exec(cmd)
            p.inputStream.bufferedReader().readText()
        } catch (e: Exception) {
            e.message ?: ""
        }
    }

    fun destroy() {
        process?.destroy()
        readerThread?.interrupt()
    }

    private fun log(msg: String) {
        terminalView.post {
            terminalView.append(msg + "\n")
            scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun logRaw(msg: String) {
        terminalView.post {
            terminalView.append(msg)
            scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }
}
