package com.maandev.terminal

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/**
 * Full Terminal Activity with vim/nano support
 * Uses PTY + xterm-256color + extra keys
 */
class VimTerminalActivity : AppCompatActivity() {

    private lateinit var terminalView: TextView
    private lateinit var inputView: EditText
    private lateinit var scrollView: ScrollView
    private lateinit var extraKeysView: ExtraKeysView
    private lateinit var modeSwitch: Switch
    private lateinit var linuxManager: LinuxManager
    private lateinit var terminalBridge: TerminalBridge
    private lateinit var ptyManager: PtyManager

    private var vimMode = false
    private var ctrlActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Top bar with mode switch
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16,8,16,8)
        }
        modeSwitch = Switch(this).apply {
            text = "VIM Mode OFF"
            setOnCheckedChangeListener { _, isChecked ->
                vimMode = isChecked
                text = if (isChecked) "VIM Mode ON" else "VIM Mode OFF"
                if (isChecked) {
                    inputView.hint = "VIM: i=insert, ESC=:wqa, arrows navigate"
                    Toast.makeText(context, "VIM/NANO mode: Extra keys will send raw escape codes", Toast.LENGTH_LONG).show()
                } else {
                    inputView.hint = "$ type command..."
                }
            }
        }
        val installBtn = Button(this).apply {
            text = "Install vim/nano"
            setOnClickListener { installVimNano() }
        }
        topBar.addView(modeSwitch, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        topBar.addView(installBtn)

        scrollView = ScrollView(this)
        terminalView = TextView(this).apply {
            text = "MAAN-TERMINAL v2.0 - VIM/NANO READY\n" +
                    "================================\n" +
                    "• vim, nano, emacs now supported\n" +
                    "• Toggle VIM Mode for raw keys\n" +
                    "• Extra keys send escape sequences\n\n"
            setTextIsSelectable(true)
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(16,16,16,16)
        }
        scrollView.addView(terminalView)

        extraKeysView = ExtraKeysView(this).apply {
            onKeyListener = { key ->
                if (vimMode || ctrlActive) {
                    terminalBridge.sendCommandRaw(key)
                } else {
                    // In normal mode, some keys still raw
                    when (key) {
                        "\t" -> terminalBridge.sendCommandRaw(key)
                        else -> {
                            if (key.length == 1 && key[0].isLetterOrDigit().not() && key in listOf("/", "-", "|")) {
                                inputView.append(key)
                            } else {
                                terminalBridge.sendCommandRaw(key)
                            }
                        }
                    }
                }
            }
            onCtrlListener = {
                ctrlActive = !ctrlActive
                setSpecialKeysEnabled(ctrlActive)
            }
        }

        inputView = EditText(this).apply {
            hint = "$ type command..."
            typeface = android.graphics.Typeface.MONOSPACE
            setSingleLine(true)
        }

        rootLayout.addView(topBar)
        rootLayout.addView(scrollView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        rootLayout.addView(extraKeysView)
        rootLayout.addView(inputView)

        setContentView(rootLayout)

        linuxManager = LinuxManager(this)
        terminalBridge = TerminalBridge(this, terminalView, scrollView)
        ptyManager = PtyManager(this)

        inputView.setOnEditorActionListener { _, _, _ ->
            val cmd = inputView.text.toString()
            if (cmd.isNotBlank()) {
                handleInput(cmd)
                inputView.text.clear()
            }
            true
        }

        appendLog("Checking runtime...")
        linuxManager.init(
            onLog = { appendLog(it) },
            onReady = { 
                appendLog("✓ Linux ready")
                ptyManager.setupVimNano(linuxManager.rootfsDir)
                appendLog("✓ vim/nano config done")
                appendLog("Starting shell with PTY support...\n")
                startTerminal() 
            },
            onError = { appendLog("✗ Error: $it") }
        )
    }

    private fun handleInput(cmd: String) {
        // Detect vim/nano invocation
        val isVimNano = cmd.trim().let {
            it.startsWith("vim ") || it == "vim" || 
            it.startsWith("nano ") || it == "nano" ||
            it.startsWith("vi ") || it.startsWith("emacs")
        }

        if (isVimNano && !vimMode) {
            appendLog("\n⚠ Tip: Turn ON VIM Mode switch for better vim/nano experience!")
        }

        if (ctrlActive) {
            when (cmd.lowercase()) {
                "c" -> terminalBridge.sendCommandRaw("\u0003")
                "d" -> terminalBridge.sendCommandRaw("\u0004")
                "z" -> terminalBridge.sendCommandRaw("\u001A")
                "l" -> terminalBridge.sendCommandRaw("\u000C")
                "x" -> {
                    // CTRL+X for nano exit
                    terminalBridge.sendCommandRaw("\u0018")
                }
                else -> terminalBridge.sendCommand(cmd)
            }
            ctrlActive = false
            extraKeysView.setSpecialKeysEnabled(false)
        } else {
            terminalBridge.sendCommand(cmd)
        }
    }

    private fun installVimNano() {
        appendLog("\n📦 Installing vim & nano...")
        terminalBridge.sendCommand("apt update && apt install -y vim nano && echo '✓ vim & nano installed'")
    }

    private fun startTerminal() {
        val cmd = linuxManager.getLaunchCommand()
        terminalBridge.openShell(cmd)
        // After shell starts, setup
        android.os.Handler(mainLooper).postDelayed({
            terminalBridge.sendCommand("export TERM=xterm-256color && alias vim='vim -u ~/.vimrc' && echo 'VIM/NANO ready - type vim file.txt or nano file.txt'")
        }, 2000)
    }

    private fun appendLog(msg: String) {
        runOnUiThread {
            terminalView.append(msg + "\n")
            scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }
}
