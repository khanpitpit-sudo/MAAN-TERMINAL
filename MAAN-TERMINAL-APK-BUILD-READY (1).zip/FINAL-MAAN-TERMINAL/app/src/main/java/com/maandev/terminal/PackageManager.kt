package com.maandev.terminal

class PackageManager(private val bridge: TerminalBridge) {

    fun install(pkg: String) {
        bridge.sendCommand("apt update && apt install -y $pkg")
    }

    fun remove(pkg: String) {
        bridge.sendCommand("apt remove -y $pkg")
    }

    fun search(query: String) {
        bridge.sendCommand("apt search $query")
    }

    fun listInstalled() {
        bridge.sendCommand("apt list --installed")
    }

    fun updateAll() {
        bridge.sendCommand("apt update && apt upgrade -y")
    }

    fun execCustom(cmd: String) {
        bridge.sendCommand(cmd)
    }
}
