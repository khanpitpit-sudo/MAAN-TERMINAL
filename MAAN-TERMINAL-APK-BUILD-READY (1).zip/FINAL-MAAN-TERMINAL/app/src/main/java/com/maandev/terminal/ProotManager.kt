package com.maandev.terminal

import android.content.Context
import java.io.File

class ProotManager(private val ctx: Context) {

    fun buildCommand(rootfs: File, prootBin: File): Array<String> {
        val tmpDir = File(ctx.cacheDir, "proot-tmp").apply { mkdirs() }
        
        // Full proot command with all necessary binds
        return arrayOf(
            prootBin.absolutePath,
            "--rootfs=${rootfs.absolutePath}",
            "--root-id",
            "--link2symlink",
            "--kill-on-exit",
            "--cwd=/root",
            "--bind=/dev",
            "--bind=/proc",
            "--bind=/sys",
            "--bind=/sdcard:/sdcard",
            "--bind=/storage:/storage",
            "--bind=${tmpDir.absolutePath}:/dev/shm",
            "--bind=${rootfs.absolutePath}/root:/dev/shm", // fallback
            "/bin/bash",
            "--login"
        )
    }

    fun buildCommandWithCustomShell(rootfs: File, prootBin: File, command: String): Array<String> {
        val base = buildCommand(rootfs, prootBin).toMutableList()
        // replace login shell with -c command
        return base.dropLast(2).toMutableList().apply {
            add("/bin/bash")
            add("-c")
            add(command)
        }.toTypedArray()
    }
}
